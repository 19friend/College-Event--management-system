<hr class = "footerline"><!--css modified horizontal line-->
<footer>
    <div class = "container">
        <h6 style="text-align:center;"> Copyright @ 2022 By: Suman Mallikarjun Hugar</h6>
    </div>
</footer>